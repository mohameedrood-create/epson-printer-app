package com.epsonprintpro.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN_DOCUMENT = 4107;
    private static final String LOCAL_START_URL = "file:///android_asset/www/index.html";
    private static final String EPSON_IPRINT_PACKAGE = "epson.print";

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileCallback;
    private volatile Uri selectedDocument;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(0xFF172438);
        getWindow().setNavigationBarColor(0xFF172438);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF4F6F8);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);

        webView.addJavascriptInterface(new NativeBridge(), "AndroidPrint");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                return !url.startsWith("file:///android_asset/www/");
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) {
                    pendingFileCallback.onReceiveValue(null);
                }
                pendingFileCallback = filePathCallback;
                openDocumentPicker();
                return true;
            }
        });

        setContentView(webView);
        webView.loadUrl(LOCAL_START_URL);
    }

    private void openDocumentPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "application/pdf",
                "image/*",
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "text/plain"
        });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_OPEN_DOCUMENT);
        } catch (ActivityNotFoundException exception) {
            finishFilePicker(null);
            Toast.makeText(this, "تعذر فتح مدير الملفات على هذا الهاتف.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_OPEN_DOCUMENT) return;

        Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
        selectedDocument = uri;
        if (uri != null && data != null) {
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) {
                // A temporary grant is sufficient for sharing during this session.
            }
        }
        finishFilePicker(uri == null ? null : new Uri[] { uri });
    }

    private void finishFilePicker(Uri[] result) {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(result);
            pendingFileCallback = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidPrint");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private final class NativeBridge {
        @JavascriptInterface
        public void openWifiSettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                } catch (ActivityNotFoundException exception) {
                    Toast.makeText(MainActivity.this, "افتح إعدادات Wi-Fi واختر شبكة الطابعة.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void shareSelectedFile(String settingsJson) {
            runOnUiThread(() -> shareToEpson());
        }

        @JavascriptInterface
        public void clearSelection() {
            selectedDocument = null;
        }

        @JavascriptInterface
        public void openEpsonIPrint() {
            runOnUiThread(() -> {
                Intent launchIntent = getPackageManager().getLaunchIntentForPackage(EPSON_IPRINT_PACKAGE);
                if (launchIntent != null) {
                    startActivity(launchIntent);
                    return;
                }
                Intent storeIntent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=epson.print"));
                try {
                    startActivity(storeIntent);
                } catch (ActivityNotFoundException ignored) {
                    Toast.makeText(MainActivity.this, "ثبّت Epson iPrint من متجر Google Play.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private void shareToEpson() {
        if (selectedDocument == null) {
            Toast.makeText(this, "اختر مستنداً أولاً، ثم أعد الإرسال.", Toast.LENGTH_LONG).show();
            return;
        }

        String mimeType = getContentResolver().getType(selectedDocument);
        if (mimeType == null || mimeType.trim().isEmpty()) mimeType = "application/octet-stream";

        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType(mimeType);
        sendIntent.putExtra(Intent.EXTRA_STREAM, selectedDocument);
        sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        sendIntent.setClipData(ClipData.newUri(getContentResolver(), "مستند الطباعة", selectedDocument));

        try {
            startActivity(Intent.createChooser(sendIntent, "إرسال الملف إلى Epson iPrint"));
            Toast.makeText(this, "اختر Epson iPrint من قائمة المشاركة لإكمال الطباعة.", Toast.LENGTH_LONG).show();
        } catch (ActivityNotFoundException exception) {
            Toast.makeText(this, "لم يعثر Android على تطبيق يستقبل هذا الملف. ثبّت Epson iPrint أولاً.", Toast.LENGTH_LONG).show();
        }
    }
}
