(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const presetKey = 'epson-print-pro-presets-v1';
  const nativeAndroid = Boolean(window.AndroidPrint);
  const state = {
    documentName: 'طلب_شهادات_الصف_التاسع.pdf',
    documentType: 'PDF',
    isSample: true,
    paper: 'A4',
    orientation: 'portrait',
    quality: 'standard',
    color: 'color',
    ink: 66,
    nup: 1,
    booklet: false,
    duplex: false,
    binding: 'right',
    copies: 1,
    pageMode: 'all',
    pageDetail: ''
  };

  const labels = {
    paper: { A4: 'A4', A5: 'A5', A3: 'A3', Letter: 'Letter', photo: 'صورة ١٠×١٥' },
    orientation: { portrait: 'طولي', landscape: 'عرضي' },
    quality: { draft: 'مسودة', standard: 'قياسية', high: 'عالية / فوتوغرافية' },
    color: { color: 'ملون', mono: 'أبيض وأسود' }
  };
  const samplePages = 8;
  let toastTimer;

  function toArabicNumber(value) {
    return String(value).replace(/[0-9]/g, digit => '٠١٢٣٤٥٦٧٨٩'[Number(digit)]);
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  }

  function getPageLabel() {
    if (state.pageMode === 'all') return state.isSample ? `كل الصفحات (${toArabicNumber(samplePages)})` : 'كل الصفحات';
    if (!state.pageDetail.trim()) return state.pageMode === 'range' ? 'اختر نطاقاً' : 'اختر الصفحات';
    return state.pageMode === 'range' ? `النطاق ${state.pageDetail}` : `الصفحات ${state.pageDetail}`;
  }

  function getPaperRatio() {
    const ratio = state.paper === 'photo' ? 10 / 15 : state.paper === 'Letter' ? 8.5 / 11 : 210 / 297;
    return state.orientation === 'landscape' ? 1 / ratio : ratio;
  }

  function renderDocument() {
    $('#document-name').textContent = state.documentName;
    $('#document-meta').textContent = state.isSample ? `ملف تجريبي · ${toArabicNumber(samplePages)} صفحات` : `${state.documentType} · اسم الملف فقط`;
    $('#document-status').textContent = state.isSample ? 'جاهز للمعاينة' : 'اختيار تجريبي';
    $('#document-card').classList.toggle('is-user-file', !state.isSample);
  }

  function renderPageMode() {
    $$('[data-page-mode]').forEach(button => {
      const active = button.dataset.pageMode === state.pageMode;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    const row = $('#page-detail-row');
    const visible = state.pageMode !== 'all';
    row.hidden = !visible;
    if (visible) {
      const isRange = state.pageMode === 'range';
      $('#page-detail-label').textContent = isRange ? 'نطاق الصفحات' : 'أرقام الصفحات';
      $('#page-detail').placeholder = isRange ? 'مثال: ١–٤' : 'مثال: ١، ٣، ٥';
      $('#page-hint').textContent = isRange ? 'اكتب بداية ونهاية النطاق' : 'افصل الأرقام بفاصلة';
      $('#page-detail').value = state.pageDetail;
    }
  }

  function makeMiniPage(index) {
    const title = state.booklet ? (index % 2 === 0 ? 'غلاف الكتيّب' : 'المحتوى') : (index === 0 ? 'طلب شهادة' : 'نموذج بيانات');
    const style = state.quality === 'draft' ? ' draft-preview' : '';
    const mono = state.color === 'mono' ? ' mono-preview' : '';
    return `<div class="mini-page${style}${mono}" aria-label="صفحة معاينة ${toArabicNumber(index + 1)}">
      <div class="mini-doc-head"><span class="mini-emblem">${state.color === 'mono' ? 'م' : 'مركز'}</span><span class="mini-title-lines"><i></i><i></i></span></div>
      <div class="mini-page-title">${title}</div>
      <div class="mini-lines"><i></i><i></i><i></i><i></i></div>
      <div class="mini-highlight"><span></span><span></span></div>
      <div class="mini-signature"><i></i><i></i></div>
      <span class="mini-page-number">${toArabicNumber(index + 1)}</span>
    </div>`;
  }

  function renderPreview() {
    const sheet = $('#paper-sheet');
    const count = Number(state.nup);
    const previewCount = Math.min(count, 16);
    const columns = count === 1 ? 1 : count <= 2 ? 2 : count <= 6 ? 3 : 4;
    sheet.style.setProperty('--paper-ratio', getPaperRatio().toFixed(3));
    sheet.style.setProperty('--ink-strength', Math.max(.34, Math.min(1, .35 + state.ink / 150)).toFixed(2));
    sheet.dataset.layout = String(count);
    if (state.color === 'mono') sheet.dataset.color = 'mono'; else delete sheet.dataset.color;
    $('#sheet-pages').style.setProperty('--sheet-columns', columns);
    $('#sheet-pages').innerHTML = Array.from({ length: previewCount }, (_, index) => makeMiniPage(index)).join('');
    $('#paper-footer-left').textContent = `${labels.paper[state.paper]} · ${labels.orientation[state.orientation]}`;
    $('#paper-footer-right').textContent = state.isSample ? `${toArabicNumber(Math.min(count, samplePages))} من ${toArabicNumber(samplePages)} صفحات` : `${toArabicNumber(count)} في الورقة`;
    const caption = state.booklet ? 'ترتيب كتيّب تجريبي · على الوجهين' : count === 1 ? 'ورقة واحدة لكل صفحة' : `${toArabicNumber(count)} صفحات في ورقة واحدة`;
    $('#preview-caption-text').textContent = caption;
    $('#paper-sheet').setAttribute('aria-label', `معاينة محاكية: ${labels.paper[state.paper]}، ${labels.orientation[state.orientation]}، ${toArabicNumber(count)} صفحة في الورقة`);
  }

  function renderSummary() {
    const pageSummary = getPageLabel();
    const items = [
      ['الورق', `${labels.paper[state.paper]} · ${labels.orientation[state.orientation]}`],
      ['الجودة', labels.quality[state.quality]],
      ['الألوان', labels.color[state.color]],
      ['كثافة الحبر', `${toArabicNumber(state.ink)}%`],
      ['التخطيط', state.booklet ? 'كتيّب · وجهان' : `${toArabicNumber(state.nup)} في الورقة`],
      ['الصفحات', pageSummary],
      ['النسخ', toArabicNumber(state.copies)]
    ];
    $('#summary-list').innerHTML = items.map(([label, value]) => `<div class="summary-item"><span>${escapeHTML(label)}</span><strong>${escapeHTML(value)}</strong></div>`).join('');
  }

  function renderControls() {
    $('#paper-size').value = state.paper;
    $('#ink-density').value = state.ink;
    $('#ink-density').style.setProperty('--slider-fill', `${state.ink}%`);
    $('#ink-value').textContent = toArabicNumber(state.ink);
    $('#copies').value = state.copies;
    $('#binding').value = state.binding;
    $$('[data-orientation]').forEach(button => {
      const active = button.dataset.orientation === state.orientation;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $$('[data-quality]').forEach(button => {
      const active = button.dataset.quality === state.quality;
      button.classList.toggle('is-selected', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $$('[data-color]').forEach(button => {
      const active = button.dataset.color === state.color;
      button.classList.toggle('is-selected', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $$('[data-nup]').forEach(button => {
      const active = Number(button.dataset.nup) === Number(state.nup);
      button.classList.toggle('is-selected', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $('#booklet-toggle').checked = state.booklet;
    $('#booklet-options').hidden = !state.booklet;
    $('#duplex-toggle').checked = state.duplex;
    $('#duplex-toggle').disabled = state.booklet;
    $('#duplex-note').textContent = state.booklet ? 'مفعّل تلقائياً لوضع الكتيّب' : 'على الوجهين';
    $('#booklet-box').classList.toggle('is-open', state.booklet);
    $('#copies-minus').disabled = state.copies <= 1;
    $('#copies-plus').disabled = state.copies >= 99;
    renderPageMode();
  }

  function render() {
    renderDocument();
    renderControls();
    renderPreview();
    renderSummary();
  }

  function announce(message) {
    const toast = $('#toast');
    toast.textContent = message;
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.hidden = true; }, 2600);
  }

  function readPresets() {
    try {
      const value = JSON.parse(localStorage.getItem(presetKey) || '[]');
      return Array.isArray(value) ? value.filter(item => item && typeof item.name === 'string' && item.settings) : [];
    } catch {
      return [];
    }
  }

  function savePresets(presets) {
    try {
      localStorage.setItem(presetKey, JSON.stringify(presets));
      return true;
    } catch {
      announce('تعذر الحفظ المحلي في هذا المتصفح.');
      return false;
    }
  }

  function renderPresets() {
    const presets = readPresets();
    const list = $('#preset-list');
    if (!presets.length) {
      list.innerHTML = '<span class="empty-presets">لا توجد إعدادات محفوظة بعد.</span>';
      return;
    }
    list.innerHTML = presets.map((preset, index) => `<div class="preset-chip"><button type="button" class="preset-load" data-preset-index="${index}" aria-label="تطبيق الإعداد ${escapeHTML(preset.name)}">${escapeHTML(preset.name)}</button><button type="button" class="preset-remove" data-remove-preset="${index}" aria-label="حذف الإعداد ${escapeHTML(preset.name)}">×</button></div>`).join('');
  }

  function snapshot() {
    const { ...copy } = state;
    return copy;
  }

  function applySnapshot(settings) {
    Object.keys(state).forEach(key => {
      if (Object.prototype.hasOwnProperty.call(settings, key)) state[key] = settings[key];
    });
    state.copies = Math.max(1, Math.min(99, Number(state.copies) || 1));
    state.ink = Math.max(0, Math.min(100, Number(state.ink) || 0));
    render();
  }

  $('#paper-size').addEventListener('change', event => { state.paper = event.target.value; render(); });
  $$('[data-orientation]').forEach(button => button.addEventListener('click', () => { state.orientation = button.dataset.orientation; render(); }));
  $$('[data-quality]').forEach(button => button.addEventListener('click', () => { state.quality = button.dataset.quality; render(); }));
  $$('[data-color]').forEach(button => button.addEventListener('click', () => { state.color = button.dataset.color; render(); }));
  $$('[data-nup]').forEach(button => button.addEventListener('click', () => { state.nup = Number(button.dataset.nup); render(); }));
  $$('[data-page-mode]').forEach(button => button.addEventListener('click', () => { state.pageMode = button.dataset.pageMode; state.pageDetail = ''; render(); if (state.pageMode !== 'all') $('#page-detail').focus(); }));
  $('#page-detail').addEventListener('input', event => { state.pageDetail = event.target.value; renderSummary(); });
  $('#ink-density').addEventListener('input', event => {
    state.ink = Number(event.target.value);
    $('#ink-value').textContent = toArabicNumber(state.ink);
    $('#ink-density').style.setProperty('--slider-fill', `${state.ink}%`);
    renderPreview();
    renderSummary();
  });
  $('#booklet-toggle').addEventListener('change', event => {
    state.booklet = event.target.checked;
    if (state.booklet) { state.duplex = true; state.nup = 2; }
    render();
  });
  $('#duplex-toggle').addEventListener('change', event => { state.duplex = event.target.checked; renderSummary(); });
  $('#binding').addEventListener('change', event => { state.binding = event.target.value; renderSummary(); });
  $('#copies').addEventListener('input', event => {
    const value = Number(event.target.value);
    if (!Number.isNaN(value) && value >= 1 && value <= 99) state.copies = Math.floor(value);
    renderSummary();
  });
  $('#copies').addEventListener('change', event => {
    state.copies = Math.max(1, Math.min(99, Math.floor(Number(event.target.value) || 1)));
    render();
  });
  $('#copies-minus').addEventListener('click', () => { state.copies = Math.max(1, state.copies - 1); render(); });
  $('#copies-plus').addEventListener('click', () => { state.copies = Math.min(99, state.copies + 1); render(); });

  $('#choose-file').addEventListener('click', () => $('#file-input').click());
  $('#file-input').addEventListener('change', event => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const ext = (file.name.split('.').pop() || '').toUpperCase();
    const typeMap = { JPEG: 'JPG', DOCX: 'Word', DOC: 'Word', XLSX: 'Excel', XLS: 'Excel', TXT: 'نص' };
    state.documentName = file.name;
    state.documentType = typeMap[ext] || ext || 'ملف';
    state.isSample = false;
    state.pageMode = 'all';
    state.pageDetail = '';
    render();
    announce(nativeAndroid ? 'تم اختيار الملف من الهاتف؛ يمكنك إرساله إلى Epson iPrint.' : 'تم اختيار اسم الملف للعرض فقط؛ لم تتم قراءة الملف.');
    event.target.value = '';
  });
  $('#load-sample').addEventListener('click', () => {
    if (nativeAndroid) window.AndroidPrint.clearSelection();
    state.documentName = 'طلب_شهادات_الصف_التاسع.pdf';
    state.documentType = 'PDF';
    state.isSample = true;
    state.pageMode = 'all';
    state.pageDetail = '';
    render();
    announce('تمت استعادة بيانات المستند التجريبي.');
  });

  $('#save-preset').addEventListener('click', () => {
    const nameField = $('#preset-name');
    const name = nameField.value.trim() || `إعداد ${toArabicNumber(readPresets().length + 1)}`;
    const presets = readPresets();
    presets.unshift({ id: `${Date.now()}-${Math.random().toString(16).slice(2, 7)}`, name, settings: snapshot() });
    if (savePresets(presets)) {
      nameField.value = '';
      renderPresets();
      announce(`تم حفظ «${name}» على هذا الجهاز.`);
    }
  });
  $('#preset-list').addEventListener('click', event => {
    const loadButton = event.target.closest('[data-preset-index]');
    const removeButton = event.target.closest('[data-remove-preset]');
    if (loadButton) {
      const preset = readPresets()[Number(loadButton.dataset.presetIndex)];
      if (preset) { applySnapshot(preset.settings); announce(`تم تطبيق «${preset.name}».`); }
    }
    if (removeButton) {
      const index = Number(removeButton.dataset.removePreset);
      const presets = readPresets();
      presets.splice(index, 1);
      if (savePresets(presets)) { renderPresets(); announce('تم حذف الإعداد المسبق.'); }
    }
  });

  $('#simulate-print').addEventListener('click', () => {
    if (nativeAndroid) {
      if (state.isSample) {
        announce('اختر ملفاً حقيقياً من الهاتف قبل الإرسال.');
        return;
      }
      window.AndroidPrint.shareSelectedFile(JSON.stringify(snapshot()));
      return;
    }
    const dialog = $('#dialog-backdrop');
    $('#dialog-summary').textContent = `${state.documentName} · ${labels.paper[state.paper]} · ${labels.quality[state.quality]} · ${toArabicNumber(state.copies)} ${state.copies === 1 ? 'نسخة' : 'نسخ'}.`;
    dialog.hidden = false;
    $('#close-dialog').focus();
  });
  $('#wifi-direct').addEventListener('click', () => {
    if (nativeAndroid) {
      announce('اختر شبكة الطابعة وكلمة المرور الظاهرة على شاشة WF‑C5790.');
      window.AndroidPrint.openWifiSettings();
    } else {
      announce('على WF‑C5790 فعّل Wi‑Fi Direct ثم اتصل بشبكتها من إعدادات Wi‑Fi.');
    }
  });
  $('#open-iprint').addEventListener('click', () => {
    if (nativeAndroid) window.AndroidPrint.openEpsonIPrint();
  });
  $('#close-dialog').addEventListener('click', () => {
    $('#dialog-backdrop').hidden = true;
    $('#simulate-print').focus();
  });
  $('#dialog-backdrop').addEventListener('click', event => {
    if (event.target.id === 'dialog-backdrop') $('#close-dialog').click();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !$('#dialog-backdrop').hidden) $('#close-dialog').click();
  });

  let deferredInstallPrompt = null;
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    deferredInstallPrompt = event;
    $('#install-app').hidden = false;
  });
  $('#install-app').addEventListener('click', async () => {
    if (!deferredInstallPrompt) {
      announce('من قائمة Chrome اختر «إضافة إلى الشاشة الرئيسية».');
      return;
    }
    deferredInstallPrompt.prompt();
    const result = await deferredInstallPrompt.userChoice;
    announce(result.outcome === 'accepted' ? 'بدأ تثبيت التطبيق على الهاتف.' : 'أُلغي طلب التثبيت.');
    deferredInstallPrompt = null;
    $('#install-app').hidden = true;
  });
  window.addEventListener('appinstalled', () => {
    $('#install-app').hidden = true;
    announce('تم تثبيت التطبيق على هذا الهاتف.');
  });
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js', { scope: './' }).catch(() => {
      console.info('التشغيل دون اتصال غير متاح في سياق المعاينة هذا.');
    });
  }

  if (nativeAndroid) {
    $('#wifi-direct').hidden = false;
    $('#open-iprint').hidden = false;
    $('.workspace-label').textContent = 'تطبيق Android';
    $('.connection-pill').textContent = 'WF‑C5790 · Wi‑Fi Direct';
    $('.demo-stamp strong').textContent = 'إرسال عبر Epson iPrint';
    $('.demo-stamp small').textContent = 'مشاركة فعلية للملف';
    $('#simulate-print').innerHTML = '<span class="print-button-icon" aria-hidden="true">⌁</span> إرسال إلى Epson iPrint <span class="button-arrow" aria-hidden="true">←</span>';
    $('.print-disclaimer').textContent = 'يفتح قائمة مشاركة Android؛ اختر Epson iPrint وأكّد الطباعة هناك.';
    $('.app-footer span:last-child').textContent = 'تطبيق Android تجريبي يضمّن الواجهة محلياً ويشارك الملف إلى Epson iPrint؛ لا يحتوي تعريف Epson مستقلاً.';
  }

  render();
  renderPresets();
})();
