# Epson Print Pro — مشروع Android قابل للبناء عبر GitHub Actions

هذا مشروع تجريبي قابل للبناء كـ **APK للتثبيت اليدوي**. يضم واجهة Epson Print Pro محلياً داخل التطبيق، ويفتح إعدادات Wi‑Fi في الهاتف، ثم يشارك المستند المختار عبر قائمة مشاركة Android. اختر **Epson iPrint** لإتمام الطباعة على WF‑C5790 عبر Wi‑Fi Direct.

> هذا المشروع لا يحتوي تعريف Epson خاصاً ولا ينفّذ بروتوكول ESC/P‑R بنفسه. يتطلب تثبيت Epson iPrint على الهاتف وإكمال مهمة الطباعة من داخله. خيارات المعاينة في الواجهة ليست كلها إعدادات طباعة مفروضة على الطابعة؛ راجع الخيارات الفعلية في Epson iPrint قبل الضغط على طباعة.

## الاتصال المباشر بالطابعة

1. على الطابعة: افتح **Wi‑Fi Direct** ثم **Start Setup**، واتبع الشاشة حتى يظهر اسم الشبكة (SSID) وكلمة المرور.
2. في التطبيق اضغط **الاتصال عبر Wi‑Fi Direct**، أو افتح إعدادات Wi‑Fi يدوياً، واختر شبكة الطابعة وأدخل كلمة المرور الظاهرة عليها. لا يلزم راوتر.
3. ثبّت [Epson iPrint من Google Play](https://play.google.com/store/apps/details?id=epson.print) وافتحه مرة واحدة إذا لم يكن مُعداً.
4. ارجع إلى Epson Print Pro، اختر ملفاً، واضغط **إرسال إلى Epson iPrint**.
5. من قائمة المشاركة اختر Epson iPrint، واختر WF‑C5790، ثم أكّد إعدادات الطباعة داخل Epson iPrint.

تؤكد Epson دعم WF‑C5790 للاتصال المباشر بلا راوتر في [دليل Wi‑Fi Direct](https://epson.com/faq/SPT_C11CG02201~faq-00005ef-wfc5710_5790)، وتشرح [إعداد Epson iPrint على Android](https://epson.com/Support/wa00877). إذا لم يظهر Epson iPrint في قائمة المشاركة لنوع ملف معيّن، افتح Epson iPrint واختر الملف من داخله.

## بناء APK سحابياً عبر GitHub Actions

1. فك ضغط مجلد المشروع وارفع **محتوياته كلها** إلى مستودع GitHub جديد، مع إبقاء مجلد `.github/workflows` موجوداً.
2. عند الدفع إلى `main` يبدأ سير العمل `Build Android APK` تلقائياً. ويمكن تشغيله يدوياً من **Actions → Build Android APK → Run workflow**.
3. بعد نجاح المهمة افتح تشغيل الـ workflow، ثم نزّل artifact باسم `Epson-Print-Pro-Android-debug`.
4. فك ضغط artifact وانقل `app-debug.apk` إلى الهاتف وافتحه. وافق في Android على **التثبيت من هذا المصدر** عند ظهور طلب النظام.

أوامر رفع المشروع من Terminal بعد إنشاء مستودع فارغ:

```bash
git init
git add .
git commit -m "Build Epson Print Pro Android app"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

استبدل `USERNAME/REPOSITORY` بعنوان مستودعك. لا تضع كلمات مرور أو مفاتيح في ملفات المشروع.

## نوع APK والتحديثات

- الـ workflow ينتج **debug APK موقّعاً تلقائياً** للتثبيت الشخصي والاختبار؛ ليس إصداراً للنشر في Google Play.
- لأن GitHub runner قد يولّد مفتاح debug مختلفاً في كل تشغيل، احذف النسخة السابقة من الهاتف قبل تثبيت APK جديد إذا ظهر تعارض توقيع. النشر التجاري يحتاج إعداد توقيع release بمفتاح خاص يُحفظ في GitHub Secrets، لا داخل المستودع.
- لا يحتاج التطبيق إلى حساب أو خادم أو اتصال إنترنت لتشغيل واجهته. صفحة الواجهة ومواردها مضمنة في APK؛ الإنترنت يُفتح فقط إذا اختار المستخدم زر متجر Epson iPrint.
- التطبيق لا يتصل تلقائياً بشبكة الطابعة ولا يقرأ كلمة مرورها. يفتح إعدادات Wi‑Fi ويختار المستخدم SSID وكلمة المرور يدوياً وفق صلاحيات Android.
- يدعم هذا الربط مشاركة الملفات إلى تطبيق Epson؛ أما ترتيب الكتيبات، صفحات لكل ورقة، وكثافة الحبر فقد لا تنتقل من واجهة المعاينة، وتحددها خدمة Epson/إعدادات Epson iPrint.

## البنية

- `app/src/main/assets/www/`: واجهة HTML/CSS/JavaScript المضمّنة وتعمل دون اتصال.
- `app/src/main/java/com/epsonprintpro/app/MainActivity.java`: حاوية Android، مستندات Android، فتح Wi‑Fi، وتمرير الملف إلى قائمة المشاركة بصلاحية قراءة مؤقتة.
- `.github/workflows/build-apk.yml`: بناء APK ورفعه كـ GitHub Actions artifact.
- `gradle/wrapper/`: Gradle Wrapper، لتثبيت إصدار البناء نفسه محلياً وفي GitHub Actions.
